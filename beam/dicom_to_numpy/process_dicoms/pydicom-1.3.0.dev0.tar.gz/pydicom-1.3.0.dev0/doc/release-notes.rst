.. currentmodule:: pydicom

===============
Release history
===============

.. include:: whatsnew/v1.3.0.rst

.. include:: whatsnew/v1.2.0.rst

.. include:: whatsnew/v1.1.0.rst

.. include:: whatsnew/v1.0.0.rst

.. include:: whatsnew/v0.9.9.rst

.. include:: whatsnew/v0.9.8.rst

.. include:: whatsnew/v0.9.7.rst

.. include:: whatsnew/v0.9.6.rst

.. include:: whatsnew/v0.9.5.rst

.. include:: whatsnew/v0.9.4.rst

.. include:: whatsnew/v0.9.3.rst

.. include:: whatsnew/v0.9.2.rst
