.. _image_processing_examples:

Image processing
----------------

These examples illustrate the image processing available in pydicom which can
be applied to DICOM images.
